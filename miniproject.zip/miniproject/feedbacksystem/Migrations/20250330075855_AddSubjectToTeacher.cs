﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace feedbacksystem.Migrations
{
    /// <inheritdoc />
    public partial class AddSubjectToTeacher : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Q1",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q10",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q2",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q3",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q4",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q5",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q6",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q7",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q8",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Q9",
                table: "Feedbacks");

            migrationBuilder.AddColumn<string>(
                name: "Subject",
                table: "Teachers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "AbilityToArouseInterest",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "AbilityToAttractAttention",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "AbilityToExpressIdeas",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "AbilityToGiveExamples",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "CommandOfEnglish",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                table: "Feedbacks",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "GeneralBehavior",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "KnowledgeInSubject",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PreparationAndSincerity",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Punctuality",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "WillingnessToHelp",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Subject",
                table: "Teachers");

            migrationBuilder.DropColumn(
                name: "AbilityToArouseInterest",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "AbilityToAttractAttention",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "AbilityToExpressIdeas",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "AbilityToGiveExamples",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "CommandOfEnglish",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "GeneralBehavior",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "KnowledgeInSubject",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "PreparationAndSincerity",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "Punctuality",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "WillingnessToHelp",
                table: "Feedbacks");

            migrationBuilder.AddColumn<int>(
                name: "Q1",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q10",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q2",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q3",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q4",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q5",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q6",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q7",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q8",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Q9",
                table: "Feedbacks",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
