﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace feedbacksystem.Migrations
{
    /// <inheritdoc />
    public partial class AddSubjectAndSemesterToTeacher : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Semester",
                table: "Teachers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Subject",
                table: "Teachers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Semester",
                table: "Teachers");

            migrationBuilder.DropColumn(
                name: "Subject",
                table: "Teachers");
        }
    }
}
