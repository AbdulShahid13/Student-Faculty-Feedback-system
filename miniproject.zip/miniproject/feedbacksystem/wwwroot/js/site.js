﻿// Form validation for student registration
document.addEventListener('DOMContentLoaded', function() {
    // Validate register number format on student signup
    const registerNumberInput = document.getElementById('RegisterNumber');
    if (registerNumberInput) {
        registerNumberInput.addEventListener('blur', function() {
            const pattern = /^MEE\d{2}(CS|ME|EC|CE|AI)\d{3}$/;
            if (!pattern.test(this.value)) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    }

    // Validate teacher ID format on teacher add/edit
    const teacherIdInput = document.getElementById('TeacherId');
    if (teacherIdInput) {
        teacherIdInput.addEventListener('blur', function() {
            const pattern = /^KTU-f\d{3}$/;
            if (!pattern.test(this.value)) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    }

    // Feedback form - ensure at least one radio is selected per question
    const feedbackForm = document.querySelector('form[asp-action="Feedback"]');
    if (feedbackForm) {
        feedbackForm.addEventListener('submit', function(e) {
            let isValid = true;
            const questions = document.querySelectorAll('.feedback-question');
            
            questions.forEach(question => {
                const radios = question.querySelectorAll('input[type="radio"]');
                let checked = false;
                
                radios.forEach(radio => {
                    if (radio.checked) checked = true;
                });
                
                if (!checked) {
                    question.querySelector('.text-danger').textContent = 'Please select a rating';
                    isValid = false;
                } else {
                    question.querySelector('.text-danger').textContent = '';
                }
            });
            
            if (!isValid) e.preventDefault();
        });
    }
});

// Function to export reports to Excel (placeholder)
function exportToExcel() {
    // This would be implemented with a library like SheetJS
    console.log('Export to Excel functionality would be implemented here');
}